# 함수 구현
def welcome():
    return '안녕하세요'