# 함수구현
def welcome():
    return 'hello'