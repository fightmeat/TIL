import y

result = y.getSum(8, 9, 10)
print(f"y.getSum(8, 9, 10) : {result}")