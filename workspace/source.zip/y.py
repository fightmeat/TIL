def getSum(a, b, c):
    return a + b + c


if __name__ == "__main__":
    result = getSum(1, 2, 3)
    print(f"getSum(1, 2, 3) : {result}")